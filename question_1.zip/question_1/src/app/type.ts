export type Users ={
    id:number;
    email:string;
    name:string;
}

export type Query={
    allUsers:Users[];
}