import { Injectable } from '@angular/core';
import { Apollo } from 'apollo-angular';
import { HttpLink } from 'apollo-angular-link-http';
import { InMemoryCache } from 'apollo-cache-inmemory';
import { Users } from './type';
import gql from 'graphql-tag';

@Injectable({
  providedIn: 'root'
})
export class TestServiceService {
  public allUsers: Users[];
  apollo: any;
  constructor(
    apollo: Apollo,
    httpLink: HttpLink
  ) {  }

  // public getUsers = () => {
  //   this.apollo.query({
  //     query: gql`query getUsers{
  //       allUsers{
  //         id,
  //         email,
  //         name
  //       }
  //     }`
  //   }).subscribe(result => {
  //     this.allUsers = result.data as Users[];
  //   })
  // }

 

}
