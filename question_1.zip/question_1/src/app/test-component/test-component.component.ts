import { Component, OnInit, } from '@angular/core';
import {Apollo} from 'apollo-angular';
//import {Observable} from 'rxjs/Observable';
//import {map} from 'rxjs/operator';
//import gql from 'grapql-tag';
//import {allUsers} from '../type';
import { Observable } from 'apollo-link';
import { TestServiceService } from '../test-service.service';

@Component({
  selector: 'app-test-component',
  templateUrl: './test-component.component.html',
  styleUrls: ['./test-component.component.css']
})
export class TestComponentComponent implements OnInit {

  constructor(private service: TestServiceService) { }

  ngOnInit() {
  //  this.service.getUsers();
  }
title="PleaseDoRun";
}
