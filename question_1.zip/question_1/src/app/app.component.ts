import { Component, OnInit } from '@angular/core';
import { Apollo } from 'apollo-angular';
//import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators';
import gql from 'graphql-tag';
import { Users, Query } from './type';
import { Observable } from 'rxjs';
// import { Observable } from 'apollo-link';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  //users: Observable<Users[]>;
  users:Observable<Users[]>;
  constructor(private apollo: Apollo) { }

  ngOnInit() {
    this.users = this.apollo.watchQuery<Query>({
      query: gql`
      query allUsers{
        allUsers{
          id
          email,
          name
        }
      }
      `
    }).valueChanges
      .pipe(
        map(result => result.data.allUsers)
      );
      console.log("This is it");
      console.log(this.users);
  
  }
 
}
